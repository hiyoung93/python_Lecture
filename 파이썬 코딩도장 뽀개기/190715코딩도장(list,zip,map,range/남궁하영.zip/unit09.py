s = """'Python' is a "programming language"
that lets you work quickly
and
integrate systems more effectively."""
print(s)