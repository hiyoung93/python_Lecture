a = input()
b = input()
print(a[1::2]+b[0::2])