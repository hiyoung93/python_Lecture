

a = map(str, input().split())
b = map(float, input().split())

print(dict(zip(a,b)))