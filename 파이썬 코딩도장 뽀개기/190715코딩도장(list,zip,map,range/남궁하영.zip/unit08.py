a,b,c,d = map(int, input().split())
print(a >= 90 and b > 80 and c > 85 and d >= 80)