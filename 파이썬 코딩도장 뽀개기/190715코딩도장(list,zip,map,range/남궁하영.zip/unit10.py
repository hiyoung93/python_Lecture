step = int(input())
tuple(range(-10, 10, step))